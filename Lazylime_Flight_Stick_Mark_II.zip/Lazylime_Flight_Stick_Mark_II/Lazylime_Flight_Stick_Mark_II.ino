#include <Wire.h>
#include <Joystick.h>

// -------------------- I2C ADDRESSES --------------------
#define PCF1_ADDR  0x20
#define PCF2_ADDR  0x25    // << UPDATED
#define ADS1_ADDR  0x49
#define ADS2_ADDR  0x48
#define DRV_ADDR   0x5A    // fixed for DRV2605L

// -------------------- PCF8575 STATES --------------------
uint16_t pcf1_state = 0xFFFF;
uint16_t pcf2_state = 0xFFFF;

// -------------------- ADS1115 REGISTERS --------------------
#define ADS_REG_CONVERSION 0x00
#define ADS_REG_CONFIG     0x01

uint16_t ads_config_base =
  0x8000 |  // Start single conversion
  0x0180 |  // PGA ±4.096V
  0x0100 |  // Single-shot mode
  0x0080 |  // 128 SPS
  0x0003;   // Comparator disabled

// -------------------- HAPTIC DRIVER (DRV2605L) --------------------
void drv_start()
{
  Wire.beginTransmission(DRV_ADDR);
  Wire.write(0x17);
  Wire.write(0x03);
  Wire.endTransmission();
  delay(10);
}

void drv_vibrate(uint8_t strength)
{
  Wire.beginTransmission(DRV_ADDR);
  Wire.write(0x16);
  Wire.write(strength);
  Wire.endTransmission();
}

// -------------------- ADS1115 RAW READ --------------------
int16_t ADS1115_read(uint8_t addr, uint8_t channel)
{
  uint16_t cfg = ads_config_base;

  switch (channel) {
    case 0: cfg |= 0x4000; break; // AIN0
    case 1: cfg |= 0x5000; break; // AIN1
    case 2: cfg |= 0x6000; break; // AIN2
    case 3: cfg |= 0x7000; break; // AIN3
  }

  Wire.beginTransmission(addr);
  Wire.write(ADS_REG_CONFIG);
  Wire.write((cfg >> 8) & 0xFF);
  Wire.write(cfg & 0xFF);
  Wire.endTransmission();

  delay(8);

  Wire.beginTransmission(addr);
  Wire.write(ADS_REG_CONVERSION);
  Wire.endTransmission();
  Wire.requestFrom((int)addr, 2);

  int16_t value = (Wire.read() << 8) | Wire.read();
  return value;
}

// -------------------- READ PCF8575 --------------------
uint16_t read_pcf(uint8_t addr)
{
  Wire.requestFrom((int)addr, 2);
  uint8_t low = Wire.read();
  uint8_t high = Wire.read();
  return (high << 8) | low;
}

// -------------------- USB JOYSTICK --------------------
Joystick_ Joystick(
  JOYSTICK_DEFAULT_REPORT_ID,
  JOYSTICK_TYPE_GAMEPAD,
  26,
  0,
  true, true, false, true, true, false,
  false, false, false
);

// -------------------- SETUP --------------------
void setup()
{
  Wire.begin();
  delay(50);

  drv_start();
  drv_vibrate(100);
  delay(100);
  drv_vibrate(0);

  Joystick.begin();
}

// -------------------- LOOP --------------------
void loop()
{
  // ---------- PCF8575 BUTTON READ ----------
  pcf1_state = read_pcf(PCF1_ADDR);
  pcf2_state = read_pcf(PCF2_ADDR);

  for (int i = 0; i < 13; i++) {
    bool pressed = !(pcf1_state & (1 << i));
    Joystick.setButton(i, pressed);
  }

  for (int i = 0; i < 13; i++) {
    bool pressed = !(pcf2_state & (1 << i));
    Joystick.setButton(i + 13, pressed);
  }

  // ---------- ADS1115 AXES ----------
  int16_t ax0 = ADS1115_read(ADS1_ADDR, 0);
  int16_t ay0 = ADS1115_read(ADS1_ADDR, 1);

  int16_t ax1 = ADS1115_read(ADS2_ADDR, 0);
  int16_t ay1 = ADS1115_read(ADS2_ADDR, 1);

  int X  = map(ax0, -32768, 32767, 0, 1023);
  int Y  = map(ay0, -32768, 32767, 0, 1023);
  int RX = map(ax1, -32768, 32767, 0, 1023);
  int RY = map(ay1, -32768, 32767, 0, 1023);

  Joystick.setXAxis(X);
  Joystick.setYAxis(Y);
  Joystick.setRxAxis(RX);
  Joystick.setRyAxis(RY);

  delay(5);
}
